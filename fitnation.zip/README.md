P1

1. Add and Format the Event Description
2. Add Package Card in the Event Detail Page (General - 1199) and Kids (Kids(3-9) - done
3. Increse the Event Detail Page Banner Height - done
4. Add Field (Emergency Phone Number, Community )
5. Connect with Real User ID and Pass of (SSL COMMERZ)
6. Increase the Checkout Page Banner Height\
7. Show Lower Price initially in the Event Card

#Optional

1. Add Count Down
